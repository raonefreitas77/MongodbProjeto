import tkinter as tk
from tkinter import messagebox
from pymongo import MongoClient


# Função para conectar ao MongoDB Atlas e acessar o banco de dados
def connect_to_mongo():
    try:
        # Conecte-se ao MongoDB com suas credenciais
        client = MongoClient("mongodb+srv://root:123@cluster0.zbxjy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
        
        # Acesse o banco de dados
        db = client['Projetinho']  # Substitua pelo nome do banco de dados
        return db
    except Exception as e:
        raise Exception(f"Não foi possível conectar ao MongoDB: {str(e)}")


