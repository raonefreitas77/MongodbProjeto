from conector import connect_to_mongo
from cryptography.fernet import Fernet
import os
from datetime import datetime, timedelta

db = connect_to_mongo()
paciente_colecao = db['dadosPaciente']


if os.path.exists("chave.key"):
    with open("chave.key", "rb") as chave_file:
        chave = chave_file.read()  
else:
    chave = Fernet.generate_key()  
    with open("chave.key", "wb") as chave_file:
        chave_file.write(chave)  

fernet = Fernet(chave)

def adicionarPaciente(nomePaciente, historico, medico, tratamentos):
    paciente = {
        "nomePaciente": fernet.encrypt(nomePaciente.encode()),
        "historico": fernet.encrypt(historico.encode()),
        "medico": fernet.encrypt(medico.encode()),
        "tratamentos": fernet.encrypt(tratamentos.encode())
    }
    paciente_colecao.insert_one(paciente)

def consultarPacientes():
    pacientes = paciente_colecao.find()
    pacientes_descriptografados = []

    for paciente in pacientes:
        paciente_descriptografado = {
            "nomePaciente": fernet.decrypt(paciente["nomePaciente"]).decode(),
            "historico": fernet.decrypt(paciente["historico"]).decode(),
            "medico": fernet.decrypt(paciente["medico"]).decode(),
            "tratamentos": fernet.decrypt(paciente["tratamentos"]).decode()
        }
        pacientes_descriptografados.append(paciente_descriptografado)

    return pacientes_descriptografados

def consultarPaciente(nomePaciente):
    pacientes = paciente_colecao.find()

    for paciente in pacientes:
        paciente_descriptografado = {
            "nomePaciente": fernet.decrypt(paciente["nomePaciente"]).decode(),
            "historico": fernet.decrypt(paciente["historico"]).decode(),
            "medico": fernet.decrypt(paciente["medico"]).decode(),
            "tratamentos": fernet.decrypt(paciente["tratamentos"]).decode()
        }
      
    if paciente_descriptografado["nomePaciente"] == nomePaciente:    
        return paciente_descriptografado  # Retorna os dados do paciente se encontrado
    else:
        return None

def atualizarPaciente(nomePaciente, novosDados):
    pacientes = paciente_colecao.find()
    
    for paciente in pacientes:
        nomePacienteDescriptografado = fernet.decrypt(paciente["nomePaciente"]).decode()
        if nomePacienteDescriptografado == nomePaciente:
            novosDadosCriptografados = {chave: fernet.encrypt(valor.encode()) for chave, valor in novosDados.items()}
            
           
            paciente_colecao.update_one(
                {"_id": paciente["_id"]},
                {"$set": novosDadosCriptografados}
            )
            print(f"Paciente {nomePaciente} atualizado com sucesso.")
            return True
    
    print(f"Paciente {nomePaciente} não encontrado.")
    return False

def removerPaciente(nomePaciente):
   
    pacientes = paciente_colecao.find()
    
    for paciente in pacientes:
        nomePacienteDescriptografado = fernet.decrypt(paciente["nomePaciente"]).decode()
        if nomePacienteDescriptografado == nomePaciente:
            paciente_colecao.delete_one({"_id": paciente["_id"]})
            print(f"Paciente {nomePaciente} removido com sucesso.")
            return True
    
    print(f"Paciente {nomePaciente} não encontrado.")
    return False

    

def compartilharRegistros():
        nomePaciente = input("Digite o nome do paciente que deseja compartilhar: ")
        paciente = consultarPaciente(nomePaciente)
                    
        
        chave_temporaria = Fernet.generate_key()
        fernet_temporario = Fernet(chave_temporaria)
        prazo_valido = datetime.now() + timedelta(hours=24)

        if paciente: 
            
            dados_criptografados = {
                "nomePaciente": fernet_temporario.encrypt(paciente["nomePaciente"].encode()),
                "historico": fernet_temporario.encrypt(paciente["historico"].encode()),
                "medico": fernet_temporario.encrypt(paciente["medico"].encode()),
                "tratamentos": fernet_temporario.encrypt(paciente["tratamentos"].encode())
            }      
            print("Dados criptografados:\n\n", dados_criptografados)
            print("Chave temporária (compartilhe com segurança):\n\n", chave_temporaria.decode())
            print("Prazo de validade da chave:", prazo_valido)
            
            return chave_temporaria, dados_criptografados, prazo_valido
        else:
            print("Paciente não encontrado.")
            return None, None, None
        
def acessarDadosCompartilhados(chave_temporaria, dados_criptografados, prazo_valido):
    
    if datetime.now() > prazo_valido:
        print("A chave temporária expirou.")
        return

    fernet_temporario = Fernet(chave_temporaria)
    try:
        
        dados_descriptografados = {
            "nomePaciente": fernet_temporario.decrypt(dados_criptografados["nomePaciente"]).decode(),
            "historico": fernet_temporario.decrypt(dados_criptografados["historico"]).decode(),
            "medico": fernet_temporario.decrypt(dados_criptografados["medico"]).decode(),
            "tratamentos": fernet_temporario.decrypt(dados_criptografados["tratamentos"]).decode()
        }
        print("Dados descriptografados:", dados_descriptografados)
    except Exception as e:
        print("Erro ao descriptografar:", e)




