from pymongo import MongoClient
from dadosPaciente import *
from conector import connect_to_mongo
from cryptography.fernet import Fernet
from usuario import *
import pyotp
import smtplib
from email.mime.text import MIMEText
from datetime import datetime, timedelta

db = connect_to_mongo()  
paciente_colecao = db['dadosPaciente']  
usuario_colecao = db['usuario']


def login(email, senha):
    usuario = usuario_colecao.find_one({"email": email})
    
    # Verificar se o usuário existe e a senha está correta
    if usuario and bcrypt.checkpw(senha.encode(), usuario["senha"]):
        print("Senha correta!")

        # Gerar um código OTP e enviar por e-mail
        secret_2fa = pyotp.random_base32()
        totp = pyotp.TOTP(secret_2fa)
        codigo_2fa = totp.now()
        print(codigo_2fa)
        # Enviar o código para o e-mail do usuário
        enviar_email(email, codigo_2fa)

        # Solicitar o código OTP ao usuário para validação
        codigo_inserido = input("Digite o código 2FA enviado para seu e-mail: ")

        # Verificar se o código inserido está correto
        if totp.verify(codigo_inserido):
            print("Login bem-sucedido com 2FA!")
            return True
        else:
            print("Código 2FA incorreto. Tente novamente.")
            return False
    else:
        print("Email ou senha incorretos.")
        return False


x="S"
email = input("Digite seu email: ")
senha = input("Digite sua senha: ")

if login(email, senha):        
    while x == "S":
        print("O que você deseja fazer?")
        escolha = int(input("1 - Adicionar paciente:\n2 - Consultar pacientes:\n3 - Alterar pacientes:\n4 - Remover paciente:\n5-Compartilhar Registro Médico:\n"))

        if escolha == 1:
            nomePaciente = input("Digite o nome do paciente: ")
            
            historico = input("Digite o histórico do paciente: ")
            
            medico = input("Digite o nome do médico: ")
            
            tratamentos = input("Digite os tratamentos: ")
            
            adicionarPaciente(nomePaciente, historico, medico , tratamentos)

        elif escolha == 2:
            pacientes = consultarPacientes()
            for paciente in pacientes:
                print(paciente)  

        elif escolha == 3:
            nomePaciente = input("Digite o nome do paciente que deseja atualizar: ")
            novosDados = {}
            
            historico = input("Digite o novo histórico")
            medico = input("Digite o novo médico ")
            tratamentos = input("Digite o novo tratamento")

            novosDados["historico"] = historico
            novosDados["medico"] = medico
            novosDados["tratamentos"] = tratamentos

            if novosDados:
                atualizarPaciente(nomePaciente, novosDados)
            else:
                print("Nenhuma atualização foi realizada.")


        elif escolha == 4:
            pacienteDelete = input("Digite o nome do paciente que deseja deletar: ")
            removerPaciente(pacienteDelete)
        
        
        elif escolha == 5:
            chave,dados,prazo = compartilharRegistros()  
            print(acessarDadosCompartilhados(chave,dados,prazo))
            
        x = input("deseja continuar usando o programa? S-Sim / Qualquer tecla para sair")        
        
else:
    print("Acesso negado") 
    
    
