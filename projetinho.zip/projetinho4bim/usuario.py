from conector import connect_to_mongo
import pyotp
import smtplib
from email.mime.text import MIMEText
import bcrypt
db = connect_to_mongo()
usuario_colecao = db['usuario']


def adicionarUsuario(email,senha):
    senhaNova = gerar_hash_senha(senha)
    usuario = {"email":email, "senha": senhaNova}
    usuario_colecao.insert_one(usuario)

def consultarUsuario():
    return list(usuario_colecao.find())

def removerUsuario(email):
    usuario_colecao.delete_one({"email": email}) 
    
def gerar_hash_senha(senha):
    salt = bcrypt.gensalt()
    senha_hash = bcrypt.hashpw(senha.encode(), salt)
    return senha_hash




def enviar_email(destinatario, codigo):
    # Configurações do servidor SMTP
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587
    SMTP_USER = "raonefreitas993@gmail.com"
    SMTP_PASS = "csgb vqem gies swpd"
    
    try:
        # Configurar o conteúdo do e-mail
        assunto = "Seu código de autenticação (OTP)"
        corpo = f"Seu código de autenticação é: {codigo}\nEste código é válido por um curto período de tempo."
        msg = MIMEText(corpo)
        msg['Subject'] = assunto
        msg['From'] = SMTP_USER
        msg['To'] = destinatario

        # Enviar o e-mail
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(SMTP_USER, destinatario, msg.as_string())
        print("Código OTP enviado por e-mail.")
    except Exception as e:
        print(f"Erro ao enviar e-mail: {e}")


    
